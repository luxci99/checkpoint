<?php 
	//diretório do sistema
define("BASEPATH", dirname(__FILE__)."/");
define("BASEURL", "https://localhost/checkpoint/");
define("ADMURL", BASEURL."painel.php/");
define("URL", "https://localhost/checkpoint/");
define("CLASSESPATH","classes/");
define("MODULOSPATH", "modulos/");
define("CSSPATH", "css/");
define("JSPATH", "js/");
define('FUNCOES', 'pdv/funcoes.php');
define("MEUIP", "");
	//bando de dados
define("DBHOST", "Localhost");
define("DBUSER", "root");
define("DBPASS", "");
define("DBNAME", "checkpoint");

	//EMAIL
define("EMAIL", "");
define("EMAIL_SENHA", ""); 
?>